-- ============================================
-- 智慧商品信息管理系统 - H2 初始化脚本
-- ============================================

DROP TABLE IF EXISTS t_user_role;
DROP TABLE IF EXISTS t_user;
DROP TABLE IF EXISTS t_role;
DROP TABLE IF EXISTS t_product;
DROP TABLE IF EXISTS t_category;

-- 商品分类表
CREATE TABLE t_category (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    name        VARCHAR(100) NOT NULL,
    description VARCHAR(500) DEFAULT '',
    PRIMARY KEY (id)
);

-- 商品表
CREATE TABLE t_product (
    id          BIGINT        NOT NULL AUTO_INCREMENT,
    name        VARCHAR(200)  NOT NULL,
    price       DECIMAL(10,2) NOT NULL,
    description VARCHAR(1000) DEFAULT '',
    image       VARCHAR(500)  DEFAULT '',
    category_id BIGINT        NOT NULL,
    stock       INT           DEFAULT 0,
    create_time TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    FOREIGN KEY (category_id) REFERENCES t_category(id) ON DELETE CASCADE
);

-- 用户表
CREATE TABLE t_user (
    id       BIGINT       NOT NULL AUTO_INCREMENT,
    username VARCHAR(50)  NOT NULL,
    password VARCHAR(200) NOT NULL,
    email    VARCHAR(100) DEFAULT '',
    active   TINYINT      DEFAULT 1,
    PRIMARY KEY (id),
    CONSTRAINT uk_username UNIQUE (username)
);

-- 角色表
CREATE TABLE t_role (
    id   BIGINT      NOT NULL AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_name UNIQUE (name)
);

-- 用户角色关联表
CREATE TABLE t_user_role (
    user_id BIGINT NOT NULL,
    role_id BIGINT NOT NULL,
    PRIMARY KEY (user_id, role_id)
);

-- ============================================
-- 初始数据
-- ============================================

INSERT INTO t_role (id, name) VALUES (1, 'admin'), (2, 'normal');

INSERT INTO t_user (id, username, password, email, active) VALUES
(1, 'admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', 'admin@smart.com', 1),
(2, 'user',  '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', 'user@smart.com',  1);

INSERT INTO t_user_role (user_id, role_id) VALUES (1, 1), (2, 2);

INSERT INTO t_category (id, name, description) VALUES
(1, '智能手机', '各类品牌智能手机及配件'),
(2, '笔记本电脑', '轻薄本、游戏本、商务本'),
(3, '智能穿戴', '智能手表、手环、耳机等'),
(4, '智能家居', '智能音箱、灯具、安防设备'),
(5, '平板电脑', '各品牌平板电脑及配件');

INSERT INTO t_product (id, name, price, description, image, category_id, stock) VALUES
(1,  'iPhone 15 Pro Max',      9999.00,  'Apple A17 Pro芯片，钛金属设计',         '', 1, 150),
(2,  '华为 Mate 60 Pro',       6999.00,  '麒麟9000S芯片，卫星通话',               '', 1, 200),
(3,  '小米 14 Ultra',          5999.00,  '骁龙8 Gen3，徕卡光学镜头',              '', 1, 180),
(4,  'MacBook Pro 14 M3',      14999.00, 'M3芯片，Liquid Retina XDR屏',           '', 2, 80),
(5,  'ThinkPad X1 Carbon',     9999.00,  '13代酷睿i7，14英寸2.8K OLED屏',          '', 2, 60),
(6,  '华为 MateBook X Pro',    8999.00,  '3.1K OLED原色全面屏',                   '', 2, 100),
(7,  'Apple Watch Ultra 2',    6499.00,  'S9芯片，精准双频GPS',                   '', 3, 120),
(8,  '华为 Watch GT 4',        1488.00,  '46mm大表盘，14天超长续航',               '', 3, 300),
(9,  'AirPods Pro 2',          1899.00,  'H2芯片，自适应降噪',                    '', 3, 250),
(10, '小米 Sound Pro',         999.00,   '哈曼卡顿调音，智能语音助手',             '', 4, 200),
(11, '华为智能门锁 Pro',       2999.00,  'AI 3D人脸识别，指纹解锁',               '', 4, 90),
(12, '小米智能摄像机 C500',    349.00,   '500万像素，360°全景',                   '', 4, 500),
(13, 'iPad Pro M4',            8099.00,  'M4芯片，OLED全面屏',                    '', 5, 110),
(14, '华为 MatePad Pro 13.2',  5199.00,  '13.2英寸OLED柔性屏',                    '', 5, 85),
(15, '小米平板 6S Pro',        3299.00,  '骁龙8Gen2，12.4英寸3K屏',               '', 5, 150);
