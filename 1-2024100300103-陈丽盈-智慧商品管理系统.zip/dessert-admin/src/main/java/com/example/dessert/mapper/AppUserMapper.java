package com.example.dessert.mapper;

import com.example.dessert.entity.AppUser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AppUserMapper {

    AppUser findByUsername(String username);

    AppUser findByEmail(String email);

    List<String> findRolesByUserId(Long userId);

    void insert(AppUser user);

    void insertUserRole(@Param("userId") Long userId, @Param("roleId") Long roleId);

    Long findRoleIdByName(String roleName);

    void updatePassword(@Param("username") String username, @Param("password") String password);
}
