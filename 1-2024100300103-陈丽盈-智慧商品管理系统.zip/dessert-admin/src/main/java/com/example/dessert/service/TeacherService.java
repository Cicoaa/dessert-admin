package com.example.dessert.service;

import com.example.dessert.entity.Teacher;
import com.example.dessert.mapper.TeacherMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherService {

    private final TeacherMapper teacherMapper;

    public TeacherService(TeacherMapper teacherMapper) {
        this.teacherMapper = teacherMapper;
    }

    public List<Teacher> listAll() {
        return teacherMapper.findAllOrdered();
    }

    public Teacher getById(Long id) {
        return teacherMapper.findById(id);
    }

    public void save(Teacher teacher) {
        teacherMapper.insert(teacher);
    }

    public void update(Teacher teacher) {
        teacherMapper.update(teacher);
    }

    public void delete(Long id) {
        teacherMapper.deleteById(id);
    }
}
