package com.example.dessert.service;

import com.example.dessert.entity.News;
import com.example.dessert.mapper.NewsMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NewsService {

    private final NewsMapper newsMapper;

    public NewsService(NewsMapper newsMapper) {
        this.newsMapper = newsMapper;
    }

    public List<News> listAll() {
        return newsMapper.findAll();
    }

    public List<News> page(String keyword) {
        if (keyword != null && !keyword.isEmpty()) {
            return newsMapper.search(keyword);
        }
        return newsMapper.findAll();
    }

    public List<News> getLatest(int limit) {
        return newsMapper.findLatest(limit);
    }

    public News getById(Long id) {
        return newsMapper.findById(id);
    }

    public void save(News news) {
        newsMapper.insert(news);
    }

    public void update(News news) {
        newsMapper.update(news);
    }

    public void delete(Long id) {
        newsMapper.deleteById(id);
    }
}
