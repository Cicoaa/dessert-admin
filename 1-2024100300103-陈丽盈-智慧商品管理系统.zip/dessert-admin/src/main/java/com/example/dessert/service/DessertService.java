package com.example.dessert.service;

import com.example.dessert.entity.Dessert;
import com.example.dessert.mapper.DessertMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 商品服务类
 * - 声明式缓存（@Cacheable/@CachePut/@CacheEvict）
 * - 分布式缓存（RedisTemplate 手动控制，Redis 不可用时自动降级）
 */
@Service
public class DessertService {

    private static final Logger log = LoggerFactory.getLogger(DessertService.class);

    private final DessertMapper dessertMapper;

    @Autowired(required = false)
    private RedisTemplate<String, Object> redisTemplate;

    public DessertService(DessertMapper dessertMapper) {
        this.dessertMapper = dessertMapper;
    }

    /** Redis 是否可用 */
    private boolean redisAvailable() {
        return redisTemplate != null;
    }

    // =========================================
    // 声明式缓存：单体查询操作
    // =========================================

    @Cacheable(value = "dessert", key = "#id")
    public Dessert getById(Long id) {
        log.info("===== [声明式缓存] 执行SQL查询商品 ID={} =====", id);
        return dessertMapper.findById(id);
    }

    @CachePut(value = "dessert", key = "#dessert.id")
    public Dessert updateAndCache(Dessert dessert) {
        log.info("===== [声明式缓存] 更新商品并刷新缓存 ID={} =====", dessert.getId());
        dessertMapper.update(dessert);
        return dessert;
    }

    @CacheEvict(value = "dessert", key = "#id")
    public void delete(Long id) {
        log.info("===== [声明式缓存] 删除商品 ID={}，清除缓存 =====", id);
        dessertMapper.deleteById(id);
    }

    // =========================================
    // Redis 分布式缓存：复杂列表操作
    // =========================================

    private static final String REDIS_KEY_PREFIX = "smart:product:";
    private static final long REDIS_TTL_MINUTES = 30;

    public List<Dessert> pageWithCache(String name, Long categoryId,
                                        Double minPrice, Double maxPrice) {
        // Redis 不可用时直接查 MySQL
        if (!redisAvailable()) {
            return dessertMapper.searchWithCategory(name, categoryId, minPrice, maxPrice);
        }

        String cacheKey = REDIS_KEY_PREFIX + "list:" +
                (name != null ? name : "all") + ":" +
                (categoryId != null ? categoryId : "all") + ":" +
                (minPrice != null ? minPrice : 0) + ":" +
                (maxPrice != null ? maxPrice : 999999);

        @SuppressWarnings("unchecked")
        List<Dessert> cached = (List<Dessert>) redisTemplate.opsForValue().get(cacheKey);
        if (cached != null) {
            log.info("===== [Redis命中] 从缓存获取商品列表 =====");
            return cached;
        }

        log.info("===== [Redis未命中] 执行SQL查询商品列表 =====");
        List<Dessert> list = dessertMapper.searchWithCategory(name, categoryId, minPrice, maxPrice);
        redisTemplate.opsForValue().set(cacheKey, list, REDIS_TTL_MINUTES, TimeUnit.MINUTES);
        return list;
    }

    public void clearListCache() {
        if (redisAvailable()) {
            log.info("===== [Redis清理] 清除商品列表缓存 =====");
            redisTemplate.delete(redisTemplate.keys(REDIS_KEY_PREFIX + "list:*"));
            redisTemplate.delete(REDIS_KEY_PREFIX + "all");
        }
    }

    // =========================================
    // 基础CRUD
    // =========================================

    public List<Dessert> page(String name, Long categoryId) {
        return dessertMapper.search(name, categoryId);
    }

    public List<Dessert> listAll() {
        return dessertMapper.findAll();
    }

    public void save(Dessert dessert) {
        dessertMapper.insert(dessert);
        clearListCache();
    }

    public void update(Dessert dessert) {
        dessertMapper.update(dessert);
        clearListCache();
    }

    public List<Dessert> search(String name, Long categoryId) {
        return dessertMapper.search(name, categoryId);
    }

    public Dessert findById(Long id) {
        return dessertMapper.findById(id);
    }

    public List<Dessert> findAll() {
        return dessertMapper.findAll();
    }
}
