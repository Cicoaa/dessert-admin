package com.example.dessert.controller;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    private final PasswordEncoder passwordEncoder;

    public TestController(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/testPwd")
    public String testPwd() {
        // 数据库里admin的密码密文
        String dbEncryptPwd = "$2a$10$vI8aWBnW3fID.ZQ9GZO1hVqfK1pJhV4euyPzLk5Cu4XhNO2fgMwN3";
        boolean isMatch = passwordEncoder.matches("123456", dbEncryptPwd);
        return "明文123456 与数据库密文匹配结果：" + isMatch;
    }
}