package com.example.dessert.config;

import com.example.dessert.service.AppUserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

/**
 * Spring Security 安全配置
 * - 自定义登录页面 Login.html
 * - 自定义 UserDetailsService（从数据库加载账号和权限）
 * - URL 授权拦截：敏感接口仅对 admin 角色开放
 * - Thymeleaf sec:authorize 动态权限菜单
 */
@Configuration
@EnableWebSecurity
public class WebSecurityConfig {

    private final AppUserService appUserService;

    public WebSecurityConfig(AppUserService appUserService) {
        this.appUserService = appUserService;
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(appUserService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        // 静态资源放行
                        .requestMatchers(
                                new AntPathRequestMatcher("/css/**"),
                                new AntPathRequestMatcher("/js/**"),
                                new AntPathRequestMatcher("/images/**")
                        ).permitAll()

                        // 登录、注册、找回密码页面放行
                        .requestMatchers(
                                new AntPathRequestMatcher("/login"),
                                new AntPathRequestMatcher("/doLogin")
                        ).permitAll()
                        .requestMatchers(
                                new AntPathRequestMatcher("/register"),
                                new AntPathRequestMatcher("/doRegister")
                        ).permitAll()
                        .requestMatchers(
                                new AntPathRequestMatcher("/forgot-password"),
                                new AntPathRequestMatcher("/doForgotPassword")
                        ).permitAll()

                        // 首页和欢迎页放行（未登录也能看框架）
                        .requestMatchers(
                                new AntPathRequestMatcher("/"),
                                new AntPathRequestMatcher("/home"),
                                new AntPathRequestMatcher("/index"),
                                new AntPathRequestMatcher("/welcome")
                        ).permitAll()

                        // 商品浏览：所有认证用户可查看
                        .requestMatchers(
                                new AntPathRequestMatcher("/dessert/list"),
                                new AntPathRequestMatcher("/dessert/edit/**")
                        ).authenticated()

                        // 分类管理、商品增删改：数据库权限是 ROLE_admin，改用 hasAuthority
                        .requestMatchers(
                                new AntPathRequestMatcher("/category/**")
                        ).hasAuthority("ROLE_admin")
                        .requestMatchers(
                                new AntPathRequestMatcher("/dessert/add"),
                                new AntPathRequestMatcher("/dessert/save"),
                                new AntPathRequestMatcher("/dessert/update"),
                                new AntPathRequestMatcher("/dessert/delete/**")
                        ).hasAuthority("ROLE_admin")

                        // 其他请求需要认证
                        .anyRequest().authenticated()
                )

                // 自定义登录页面（formLogin接管登录流程）
                .formLogin(form -> form
                        .loginPage("/login")                    // 自定义登录页
                        .loginProcessingUrl("/doLogin")         // 登录表单提交URL
                        .defaultSuccessUrl("/", true)           // 登录成功跳转
                        .permitAll()
                )

                // 退出登录
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                )

                // 允许同源 iframe（伪单页框架需要）
                .headers(headers -> headers
                        .frameOptions().sameOrigin()
                )

                // 禁用CSRF（简化开发，生产环境需开启）
                .csrf(csrf -> csrf.disable());

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}