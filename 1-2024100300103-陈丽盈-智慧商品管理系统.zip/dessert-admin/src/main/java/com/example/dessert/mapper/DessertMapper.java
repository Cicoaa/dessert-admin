package com.example.dessert.mapper;

import com.example.dessert.entity.Dessert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 商品 Mapper 接口
 * - XML 方式实现复杂动态SQL（多表联查、价格区间）
 * - @Select 注解方式实现简单查询
 */
@Mapper
public interface DessertMapper {

    // ===== XML 方式：多表联查 =====

    /** 查询所有商品（带分类名称） */
    List<Dessert> findAllWithCategory();

    /** 按条件搜索（带分类名称 + 价格区间） */
    List<Dessert> searchWithCategory(@Param("name") String name,
                                     @Param("categoryId") Long categoryId,
                                     @Param("minPrice") Double minPrice,
                                     @Param("maxPrice") Double maxPrice);

    // ===== XML 方式：单表查询（兼容旧接口） =====

    List<Dessert> findAll();

    List<Dessert> search(@Param("name") String name, @Param("categoryId") Long categoryId);

    Dessert findById(Long id);

    void insert(Dessert dessert);

    void update(Dessert dessert);

    void deleteById(Long id);

    // ===== @Select 注解方式：简单查询示例 =====

    /** 根据ID查商品（注解方式 - @Select） */

// 第1处：selectById
    @Select("SELECT id, name, price, descp AS description, photo_url AS image, cat_id AS categoryId, " +
            "0 AS stock, NULL AS createTime FROM product WHERE id = #{id}")
    Dessert selectById(@Param("id") Long id);


    /** 统计商品总数 */
    @Select("SELECT COUNT(*) FROM product")
    int countAll();
    /** 统计某分类下的商品数 */
    @Select("SELECT COUNT(*) FROM product WHERE cat_id = #{categoryId}")
    int countByCategoryId(@Param("categoryId") Long categoryId);

    /** 多表联查：@Select 注解方式（商品+分类名） */
    @Select("SELECT p.id, p.name, p.price, p.descp AS description, " +
            "p.photo_url AS image, p.cat_id AS categoryId, " +
            "0 AS stock, NULL AS createTime, c.name AS categoryName " +
            "FROM product p LEFT JOIN category c ON p.cat_id = c.id " +
            "ORDER BY p.id")
    List<Dessert> findAllWithCategoryAnno();
}
