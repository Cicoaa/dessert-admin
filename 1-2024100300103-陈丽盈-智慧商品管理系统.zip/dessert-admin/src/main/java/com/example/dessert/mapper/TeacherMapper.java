package com.example.dessert.mapper;

import com.example.dessert.entity.Teacher;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface TeacherMapper {

    List<Teacher> findAll();

    List<Teacher> findAllOrdered();

    Teacher findById(Long id);

    void insert(Teacher teacher);

    void update(Teacher teacher);

    void deleteById(Long id);
}
