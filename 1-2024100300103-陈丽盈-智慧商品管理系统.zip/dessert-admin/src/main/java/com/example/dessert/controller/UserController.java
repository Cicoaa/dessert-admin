package com.example.dessert.controller;

import com.example.dessert.entity.AppUser;
import com.example.dessert.service.AppUserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class UserController {

    private final AppUserService appUserService;
    private final PasswordEncoder passwordEncoder;

    public UserController(AppUserService appUserService, PasswordEncoder passwordEncoder) {
        this.appUserService = appUserService;
        this.passwordEncoder = passwordEncoder;
    }

    /** 注册页面 */
    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("appUser", new AppUser());
        return "register";
    }

    /** 注册提交 */
    @PostMapping("/doRegister")
    public String register(AppUser appUser,
                           @RequestParam String confirmPassword,
                           RedirectAttributes redirectAttributes) {
        if (!appUser.getPassword().equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("error", "两次输入的密码不一致");
            return "redirect:/register";
        }
        if (appUserService.existsByUsername(appUser.getUsername())) {
            redirectAttributes.addFlashAttribute("error", "用户名已存在");
            return "redirect:/register";
        }
        // 删除全部邮箱判断代码
        appUser.setPassword(passwordEncoder.encode(appUser.getPassword()));
        // 替换 setEnabled(true) → setActive(1)
        appUser.setActive(1);
        appUserService.register(appUser);
        redirectAttributes.addFlashAttribute("success", "注册成功，请登录！");
        return "redirect:/login";
    }

    /** 找回密码页面（邮箱功能废弃，可保留页面或删除） */
    @GetMapping("/forgot-password")
    public String forgotPasswordPage() {
        return "forgot-password";
    }

    /** 找回密码提交（删除邮箱校验逻辑） */
    @PostMapping("/doForgotPassword")
    public String doForgotPassword(@RequestParam String username,
                                   @RequestParam String newPassword,
                                   @RequestParam String confirmPassword,
                                   RedirectAttributes redirectAttributes) {
        // 验证输入
        if (!newPassword.equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("error", "两次输入的密码不一致");
            return "redirect:/forgot-password";
        }

        AppUser user = appUserService.findByUsername(username);
        if (user == null) {
            redirectAttributes.addFlashAttribute("error", "用户名不存在");
            return "redirect:/forgot-password";
        }

        // 删除邮箱匹配校验代码

        // 重置密码
        String encodedPassword = passwordEncoder.encode(newPassword);
        appUserService.resetPassword(username, encodedPassword);
        redirectAttributes.addFlashAttribute("success", "密码重置成功，请使用新密码登录！");
        return "redirect:/login";
    }
}