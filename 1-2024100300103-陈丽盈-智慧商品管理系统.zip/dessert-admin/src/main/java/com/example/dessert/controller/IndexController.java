package com.example.dessert.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * 首页/登录/注册 Controller
 */
@Controller
public class IndexController {

    /** 系统首页（iframe框架页） */
    @GetMapping({"/", "/home", "/index"})
    public String index(Model model) {
        return "index";
    }

    /** 欢迎页（iframe内嵌） */
    @GetMapping("/welcome")
    public String welcome() {
        return "welcome";
    }

    /** 登录页面 */
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }
}
