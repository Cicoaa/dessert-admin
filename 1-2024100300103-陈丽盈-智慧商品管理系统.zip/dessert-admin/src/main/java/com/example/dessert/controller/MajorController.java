package com.example.dessert.controller;

import com.example.dessert.entity.Major;
import com.example.dessert.service.MajorService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/major")
public class MajorController {

    private final MajorService majorService;

    public MajorController(MajorService majorService) {
        this.majorService = majorService;
    }

    /** 专业列表 */
    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("majors", majorService.listAll());
        return "major/list";
    }

    /** 专业详情 */
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable Long id, Model model) {
        Major major = majorService.getById(id);
        if (major == null) {
            return "redirect:/major/list";
        }
        model.addAttribute("major", major);
        return "major/detail";
    }
}
