package com.example.dessert;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

/**
 * 智慧商品信息管理系统 - 启动类
 * @EnableCaching 开启声明式缓存（@Cacheable/@CachePut/@CacheEvict）
 * @MapperScan 扫描所有MyBatis Mapper接口，解决Mapper无法注入Service的依赖报错
 */
@SpringBootApplication
@EnableCaching
@MapperScan("com.example.dessert.mapper")
public class DessertApplication {

    public static void main(String[] args) {
        SpringApplication.run(DessertApplication.class, args);
    }
}