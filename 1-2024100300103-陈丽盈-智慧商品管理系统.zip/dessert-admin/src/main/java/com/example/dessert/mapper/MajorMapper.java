package com.example.dessert.mapper;

import com.example.dessert.entity.Major;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MajorMapper {

    List<Major> findAll();

    List<Major> findAllOrdered();

    Major findById(Long id);

    void insert(Major major);

    void update(Major major);

    void deleteById(Long id);
}
