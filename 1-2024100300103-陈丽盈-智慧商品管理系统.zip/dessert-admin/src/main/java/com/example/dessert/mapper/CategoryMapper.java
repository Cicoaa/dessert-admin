package com.example.dessert.mapper;

import com.example.dessert.entity.Category;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CategoryMapper {

    List<Category> findAll();

    List<Category> findByKeyword(String keyword);

    Category findById(Long id);

    int insert(Category category);

    void update(Category category);

    int deleteById(Long id);

    int updateById(Category category);

    List<Category> selectAll();

    Category selectById(Long id);
}
