// 已废弃 - 由 AppUserService 替代实现 UserDetailsService
package com.example.dessert.service;

/**
 * @deprecated 用户认证逻辑已迁移至 AppUserService。
 *             该文件保留仅为历史兼容，不再注册为 Spring Bean。
 */
@Deprecated
public class UserDetailsServiceImpl {
    // Intentionally empty - AppUserService now handles UserDetailsService
}
