package com.example.dessert.service;

import com.example.dessert.entity.Notice;
import com.example.dessert.mapper.NoticeMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NoticeService {

    private final NoticeMapper noticeMapper;

    public NoticeService(NoticeMapper noticeMapper) {
        this.noticeMapper = noticeMapper;
    }

    public List<Notice> listAll() {
        return noticeMapper.findAll();
    }

    public List<Notice> getLatest(int limit) {
        return noticeMapper.findLatest(limit);
    }

    public Notice getById(Long id) {
        return noticeMapper.findById(id);
    }

    public void save(Notice notice) {
        noticeMapper.insert(notice);
    }

    public void update(Notice notice) {
        noticeMapper.update(notice);
    }

    public void delete(Long id) {
        noticeMapper.deleteById(id);
    }
}
