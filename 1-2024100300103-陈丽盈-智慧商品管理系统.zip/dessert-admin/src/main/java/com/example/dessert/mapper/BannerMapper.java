package com.example.dessert.mapper;

import com.example.dessert.entity.Banner;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BannerMapper {

    /** 获取所有启用的轮播图，按排序字段排序 */
    List<Banner> findEnabledByOrder();

    List<Banner> findAll();

    Banner findById(Long id);

    void insert(Banner banner);

    void update(Banner banner);

    void deleteById(Long id);
}
