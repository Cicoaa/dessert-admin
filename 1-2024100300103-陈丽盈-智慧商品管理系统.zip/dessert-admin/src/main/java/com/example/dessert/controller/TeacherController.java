package com.example.dessert.controller;

import com.example.dessert.service.TeacherService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/teacher")
public class TeacherController {

    private final TeacherService teacherService;

    public TeacherController(TeacherService teacherService) {
        this.teacherService = teacherService;
    }

    /** 师资力量列表 */
    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("teachers", teacherService.listAll());
        return "teacher/list";
    }
}
