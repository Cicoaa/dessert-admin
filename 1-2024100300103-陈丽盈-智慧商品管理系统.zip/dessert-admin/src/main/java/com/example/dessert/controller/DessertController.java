package com.example.dessert.controller;

import com.example.dessert.entity.Category;
import com.example.dessert.entity.Dessert;
import com.example.dessert.service.CategoryService;
import com.example.dessert.service.DessertService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 商品管理 Controller
 * - 多表联查（商品+分类名称）
 * - 多条件动态组合查询（名称/分类/价格区间）
 * - PageHelper 物理分页
 * - 翻页保留搜索条件
 * - 新增库存参数打印调试，快速定位库存丢失问题
 */
@Controller
@RequestMapping("/dessert")
public class DessertController {

    private final DessertService dessertService;
    private final CategoryService categoryService;

    // 构造注入
    public DessertController(DessertService dessertService, CategoryService categoryService) {
        this.dessertService = dessertService;
        this.categoryService = categoryService;
    }

    /**
     * 商品列表（多条件搜索 + 分页）
     */
    @GetMapping("/list")
    public String list(@RequestParam(defaultValue = "1") int pageNum,
                       @RequestParam(defaultValue = "10") int pageSize,
                       @RequestParam(required = false) String name,
                       @RequestParam(required = false) Long categoryId,
                       @RequestParam(required = false) Double minPrice,
                       @RequestParam(required = false) Double maxPrice,
                       Model model) {

        PageHelper.startPage(pageNum, pageSize);
        List<Dessert> desserts = dessertService.pageWithCache(name, categoryId, minPrice, maxPrice);
        PageInfo<Dessert> pageInfo = new PageInfo<>(desserts);

        List<Category> categoryList = categoryService.listAll();
        Map<Long, String> categoryMap = new HashMap<>();
        for (Category cat : categoryList) {
            categoryMap.put(cat.getId(), cat.getName());
        }

        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("categories", categoryList);
        model.addAttribute("categoryMap", categoryMap);

        // 搜索条件回显
        model.addAttribute("name", name);
        model.addAttribute("categoryId", categoryId);
        model.addAttribute("minPrice", minPrice);
        model.addAttribute("maxPrice", maxPrice);

        return "dessert/list";
    }

    /**
     * 新增商品表单页面
     */
    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("dessert", new Dessert());
        model.addAttribute("categories", categoryService.listAll());
        return "dessert/add";
    }

    /**
     * 执行新增商品
     */
    @PostMapping("/save")
    public String save(Dessert dessert, RedirectAttributes redirectAttributes) {
        // 打印新增库存调试
        System.out.println("【新增商品】接收库存stock：" + dessert.getStock());
        dessertService.save(dessert);
        redirectAttributes.addFlashAttribute("message", "✅ 商品添加成功");
        return "redirect:/dessert/list";
    }

    /**
     * 编辑商品回显页面
     */
    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        Dessert dessert = dessertService.getById(id);
        model.addAttribute("dessert", dessert);
        model.addAttribute("categories", categoryService.listAll());
        return "dessert/edit";
    }

    /**
     * 执行商品更新（重点：库存打印调试）
     */
    @PostMapping("/update")
    public String update(Dessert dessert, RedirectAttributes redirectAttributes) {
        // 打印前端传递的库存，用来判断前端是否正常传值
        System.out.println("【更新商品】ID：" + dessert.getId() + " 接收库存stock：" + dessert.getStock());
        dessertService.update(dessert);
        redirectAttributes.addFlashAttribute("message", "✅ 商品更新成功");
        return "redirect:/dessert/list";
    }

    /**
     * 删除商品
     */
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        dessertService.delete(id);
        redirectAttributes.addFlashAttribute("message", "✅ 商品删除成功");
        return "redirect:/dessert/list";
    }
}