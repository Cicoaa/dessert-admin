package com.example.dessert.service;

import com.example.dessert.entity.AppUser;
import com.example.dessert.mapper.AppUserMapper;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AppUserService implements UserDetailsService {

    private final AppUserMapper appUserMapper;

    public AppUserService(AppUserMapper appUserMapper) {
        this.appUserMapper = appUserMapper;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AppUser appUser = appUserMapper.findByUsername(username);
        if (appUser == null) {
            throw new UsernameNotFoundException("用户不存在: " + username);
        }

        List<String> roleNames = appUserMapper.findRolesByUserId(appUser.getId());
        // 数据库角色不带 ROLE_ 前缀，需要手动拼接（Spring Security hasRole 要求 ROLE_ 前缀）
        List<SimpleGrantedAuthority> authorities = roleNames.stream()
                .map(name -> "ROLE_" + name)
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());

        return new User(
                appUser.getUsername(),
                appUser.getPassword(),
                // enabled 字段取决于数据库实际列名（active/enabled）
                // 直接信任数据库值 >= 1 表示启用
                appUser.getActive() != null && appUser.getActive() == 1,
                true,
                true,
                true,
                authorities
        );
    }

    public void register(AppUser user) {
        appUserMapper.insert(user);

        Long normalRoleId = appUserMapper.findRoleIdByName("normal");
        if (normalRoleId != null) {
            appUserMapper.insertUserRole(user.getId(), normalRoleId);
        }
    }

    public AppUser findByUsername(String username) {
        return appUserMapper.findByUsername(username);
    }

    public boolean existsByUsername(String username) {
        return appUserMapper.findByUsername(username) != null;
    }

    /** 重置密码 */
    public boolean resetPassword(String username, String newPassword) {
        AppUser user = appUserMapper.findByUsername(username);
        if (user == null) {
            return false;
        }
        appUserMapper.updatePassword(username, newPassword);
        return true;
    }
}