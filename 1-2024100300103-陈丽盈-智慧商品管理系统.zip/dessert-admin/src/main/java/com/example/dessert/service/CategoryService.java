package com.example.dessert.service;

import com.example.dessert.entity.Category;
import com.example.dessert.mapper.CategoryMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 分类服务类
 * - 声明式缓存 + Redis分布式缓存（Redis 不可用时自动降级）
 */
@Service
public class CategoryService {

    private static final Logger log = LoggerFactory.getLogger(CategoryService.class);

    private final CategoryMapper categoryMapper;

    @Autowired(required = false)
    private RedisTemplate<String, Object> redisTemplate;

    private static final String REDIS_KEY_CATEGORIES = "smart:category:all";
    private static final long REDIS_TTL_MINUTES = 60;

    public CategoryService(CategoryMapper categoryMapper) {
        this.categoryMapper = categoryMapper;
    }

    private boolean redisAvailable() {
        return redisTemplate != null;
    }

    public List<Category> listAll() {
        if (redisAvailable()) {
            @SuppressWarnings("unchecked")
            List<Category> cached = (List<Category>) redisTemplate.opsForValue().get(REDIS_KEY_CATEGORIES);
            if (cached != null) {
                log.info("===== [Redis命中] 从缓存获取分类列表 =====");
                return cached;
            }
        }

        log.info("===== [Redis未命中] 执行SQL查询分类列表 =====");
        List<Category> list = categoryMapper.selectAll();

        if (redisAvailable()) {
            redisTemplate.opsForValue().set(REDIS_KEY_CATEGORIES, list, REDIS_TTL_MINUTES, TimeUnit.MINUTES);
        }
        return list;
    }

    private void clearCache() {
        if (redisAvailable()) {
            log.info("===== [Redis清理] 清除分类列表缓存 =====");
            redisTemplate.delete(REDIS_KEY_CATEGORIES);
        }
    }

    @Cacheable(value = "category", key = "#id")
    public Category getById(Long id) {
        log.info("===== [声明式缓存] 执行SQL查询分类 ID={} =====", id);
        return categoryMapper.selectById(id);
    }

    public int add(Category category) {
        int result = categoryMapper.insert(category);
        clearCache();
        return result;
    }

    @CacheEvict(value = "category", key = "#category.id")
    public int update(Category category) {
        int result = categoryMapper.updateById(category);
        clearCache();
        return result;
    }

    @CacheEvict(value = "category", key = "#id")
    public int delete(Long id) {
        int result = categoryMapper.deleteById(id);
        clearCache();
        return result;
    }

    public List<Category> page(String keyword) {
        if (keyword != null && !keyword.isEmpty()) {
            return categoryMapper.findByKeyword(keyword);
        }
        return listAll();
    }
}
