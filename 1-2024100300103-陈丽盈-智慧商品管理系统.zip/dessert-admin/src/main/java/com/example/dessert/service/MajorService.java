package com.example.dessert.service;

import com.example.dessert.entity.Major;
import com.example.dessert.mapper.MajorMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MajorService {

    private final MajorMapper majorMapper;

    public MajorService(MajorMapper majorMapper) {
        this.majorMapper = majorMapper;
    }

    public List<Major> listAll() {
        return majorMapper.findAllOrdered();
    }

    public Major getById(Long id) {
        return majorMapper.findById(id);
    }

    public void save(Major major) {
        majorMapper.insert(major);
    }

    public void update(Major major) {
        majorMapper.update(major);
    }

    public void delete(Long id) {
        majorMapper.deleteById(id);
    }
}
