package com.example.dessert.mapper;

import com.example.dessert.entity.News;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface NewsMapper {

    List<News> findAll();

    List<News> search(@Param("keyword") String keyword);

    News findById(Long id);

    void insert(News news);

    void update(News news);

    void deleteById(Long id);

    /** 获取最新的N条新闻 */
    List<News> findLatest(@Param("limit") int limit);
}
