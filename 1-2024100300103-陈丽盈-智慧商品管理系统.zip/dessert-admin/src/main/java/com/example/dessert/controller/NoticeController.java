package com.example.dessert.controller;

import com.example.dessert.entity.Notice;
import com.example.dessert.service.NoticeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/notice")
public class NoticeController {

    private final NoticeService noticeService;

    public NoticeController(NoticeService noticeService) {
        this.noticeService = noticeService;
    }

    /** 通知公告列表 */
    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("notices", noticeService.listAll());
        return "notice/list";
    }

    /** 通知详情 */
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable Long id, Model model) {
        Notice notice = noticeService.getById(id);
        if (notice == null) {
            return "redirect:/notice/list";
        }
        model.addAttribute("notice", notice);
        return "notice/detail";
    }
}
