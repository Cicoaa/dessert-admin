package com.example.dessert.mapper;

import com.example.dessert.entity.Notice;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface NoticeMapper {

    List<Notice> findAll();

    /** 获取置顶和最��的N条公告 */
    List<Notice> findLatest(@Param("limit") int limit);

    Notice findById(Long id);

    void insert(Notice notice);

    void update(Notice notice);

    void deleteById(Long id);
}
