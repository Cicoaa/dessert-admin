package com.example.dessert.controller;

import com.example.dessert.entity.News;
import com.example.dessert.service.NewsService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/news")
public class NewsController {

    private final NewsService newsService;

    public NewsController(NewsService newsService) {
        this.newsService = newsService;
    }

    /** 新闻列表 */
    @GetMapping("/list")
    public String list(@RequestParam(defaultValue = "1") int pageNum,
                       @RequestParam(defaultValue = "8") int pageSize,
                       @RequestParam(required = false) String keyword,
                       Model model) {
        PageHelper.startPage(pageNum, pageSize);
        List<News> newsList = newsService.page(keyword);
        PageInfo<News> pageInfo = new PageInfo<>(newsList);
        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("keyword", keyword);
        return "news/list";
    }

    /** 新闻详情 */
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable Long id, Model model) {
        News news = newsService.getById(id);
        if (news == null) {
            return "redirect:/news/list";
        }
        model.addAttribute("news", news);
        return "news/detail";
    }
}
