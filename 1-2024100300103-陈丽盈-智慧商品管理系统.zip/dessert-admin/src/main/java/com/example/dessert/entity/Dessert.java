package com.example.dessert.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 商品实体类 (映射 t_product 表)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Dessert {
    private Long id;
    private String name;
    private Double price;
    private String description;
    private String image;
    private Long categoryId;
    private Integer stock;
    private String createTime;

    /** 多表联查时携带的分类名称（非数据库字段） */
    private String categoryName;
}