package com.example.dessert.entity;

/**
 * 专业介绍实体
 */
public class Major {

    private Long id;
    private String name;
    private String degree;
    private String description;
    private String courses;
    private String career;
    private String icon;
    private Integer sortOrder;

    public Major() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDegree() { return degree; }
    public void setDegree(String degree) { this.degree = degree; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCourses() { return courses; }
    public void setCourses(String courses) { this.courses = courses; }

    public String getCareer() { return career; }
    public void setCareer(String career) { this.career = career; }

    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }

    public Integer getSortOrder() { return sortOrder; }
    public void setSortOrder(Integer sortOrder) { this.sortOrder = sortOrder; }
}
