package com.example.dessert.service;

import com.example.dessert.entity.Banner;
import com.example.dessert.mapper.BannerMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BannerService {

    private final BannerMapper bannerMapper;

    public BannerService(BannerMapper bannerMapper) {
        this.bannerMapper = bannerMapper;
    }

    public List<Banner> getEnabled() {
        return bannerMapper.findEnabledByOrder();
    }

    public List<Banner> listAll() {
        return bannerMapper.findAll();
    }

    public Banner getById(Long id) {
        return bannerMapper.findById(id);
    }

    public void save(Banner banner) {
        bannerMapper.insert(banner);
    }

    public void update(Banner banner) {
        bannerMapper.update(banner);
    }

    public void delete(Long id) {
        bannerMapper.deleteById(id);
    }
}
