@echo off
REM Overwrite the locked file using a new cmd instance
copy /y "D:\AI\deepseek\dessert-admin\WebSecurityConfig_fix.java" "D:\AI\deepseek\dessert-admin\src\main\java\com\example\dessert\config\WebSecurityConfig.java"
echo EXIT_CODE=%ERRORLEVEL%
